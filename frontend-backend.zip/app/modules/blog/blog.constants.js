const BlogsFilterAbleFileds = ["searchTerm", "title"];

const BlogsSearchableFields = ["searchTerm", "title"];

module.exports = {
  BlogsFilterAbleFileds,
  BlogsSearchableFields,
};
