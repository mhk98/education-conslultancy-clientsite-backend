// const BannerSearchAbleFields = []; // Empty if you're not using search
// const BannerFilterAbleFileds = ["user_id", "assignedTo_id"]; // Now used for exact filter

// module.exports = {
//   BannerSearchAbleFields,
//   BannerFilterAbleFileds,
// };
